<?php
global $conn;
include 'conect.php';
// Procesare solicitări de actualizare
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pentru fiecare produs primit în solicitare
    foreach ($_POST as $nume_produs => $noul_pret) {
        $nume_produs = $conn->real_escape_string($nume_produs);
        $noul_pret = $conn->real_escape_string($noul_pret);

        // Actualizează prețul în baza de date
        $sql = "UPDATE tabela_produse SET pret = '$noul_pret' WHERE nume = '$nume_produs'";
        $conn->query($sql);
    }

    echo "Prețurile au fost actualizate cu succes.";
}

$conn->close();
?>
