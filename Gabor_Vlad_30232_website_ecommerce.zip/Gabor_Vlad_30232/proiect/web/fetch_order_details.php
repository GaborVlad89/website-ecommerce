<?php
global $conn;
include 'conect.php';

$query = "SELECT * FROM detalii_comanda";
$result = $conn->query($query);

// Verificați dacă interogarea a fost executată cu succes
if ($result) {
    $data = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($data);
} else {
    echo json_encode(['error' => 'Eroare la preluarea datelor despre detalii comandă']);
}

$conn->close();
?>
