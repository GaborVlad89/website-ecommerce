<?php
// Include script-ul pentru conexiune la baza de date

global $conn;
include 'conect.php';

if (
    isset($_POST['firstName'], $_POST['lastName'], $_POST['email'], $_POST['password'], $_POST['phone'])
) {
    $nume = mysqli_real_escape_string($conn, $_POST['firstName']);
    $prenume = mysqli_real_escape_string($conn, $_POST['lastName']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $parola = mysqli_real_escape_string($conn, $_POST['password']);
    $telefon = mysqli_real_escape_string($conn, $_POST['phone']);

    $sql = "INSERT INTO utilizatori (nume, prenume, email, parola, telefon) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error in preparing statement: " . $conn->error);
    }
    $stmt->bind_param("sssss", $nume, $prenume, $email, $parola, $telefon);
    if ($stmt->execute()) {
        echo "Înregistrare cu succes!";
    } else {
        echo "Eroare la înregistrare: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Eroare: Unele sau toate datele lipsesc.";
}
$conn->close();
?>
