<?php
global $conn;
include 'conect.php';

$query = "SELECT * FROM tabela_produse";
$result = $conn->query($query);

if ($result) {
    $data = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($data);
} else {
    echo json_encode(['error' => 'Eroare la preluarea datelor despre produse']);
}

$conn->close();
?>
