<?php
global $conn;
global $conn1;
include 'conect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $truncateQuery = "TRUNCATE TABLE detalii_comanda";
    if ($conn->query($truncateQuery) !== TRUE) {
        echo "Eroare la truncarea tabelului: " . $conn->error;
        exit;
    }
    $produseCos = array();
    foreach ($_POST as $key => $value) {
        preg_match('/^(.+?)(\d+)$/', $key, $matches);

        if (count($matches) === 3) {
            $index = $matches[2];
            $property = $matches[1];

            if (!isset($produseCos[$index])) {
                $produseCos[$index] = array();
            }
            $produseCos[$index][$property] = $value;
        }
    }
    foreach ($produseCos as $produs) {
        $nume_produs = $conn->real_escape_string(urldecode($produs['nume_produs']));
        $cantitate = $conn->real_escape_string($produs['cantitate']);
        $pret = $conn->real_escape_string($produs['pret']);
        $pret1=$cantitate*$pret;
        $sql = "INSERT INTO detalii_comanda (nume_produs, cantitate, pret) VALUES ('$nume_produs', $cantitate, $pret1)";
        if ($conn->query($sql) === TRUE) {
            echo "Comandă adăugată cu succes în baza de date.";
        } else {
            echo "Eroare la adăugarea comenzii în baza de date: " . $conn->error;
        }

        $sqlUpdateProdus = "UPDATE tabela_produse SET pret = $pret, stoc = stoc-$cantitate WHERE nume = '$nume_produs'";
        if ($conn->query($sqlUpdateProdus) === TRUE) {
            echo "Produsul a fost actualizat cu succes.";
        } else {
            echo "Eroare la actualizarea produsului: " . $conn->error;
        }
    }
}
?>
