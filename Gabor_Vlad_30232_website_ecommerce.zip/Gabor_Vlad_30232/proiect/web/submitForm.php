<?php
include 'submitConnectForm.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["connectEmail"];
    $password = $_POST["connectPassword"];

    // Validează și curăță datele de intrare
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    $password = trim($_POST["connectPassword"]); // Poți adăuga mai multe verificări aici, dacă este necesar

    // Verifică dacă datele de intrare sunt empty
    if (!empty($email) && !empty($password)) {
        submitConnectForm($email, $password);
    } else {
        echo "Date de conectare invalide.";
    }
}
?>
