<?php
// Conexiunea la baza de date
global $conn;
include 'conect.php';

// Exemplu: numele produsului pe care vrei să-l ștergi
$nume_produs_sters = "Nume produs nou";

// Instrucțiunea SQL pentru ștergere
$sqlStergereProdus = "DELETE FROM tabela_produse WHERE nume = '$nume_produs_sters'";

$stoc_nou = 10;
$pret_nou=5000;
$nume_produs_update="Nume_produs";

// Instrucțiunea SQL pentru update
$sqlUpdateProdus = "UPDATE tabela_produse SET pret = $pret_nou, stoc = $stoc_nou WHERE nume = '$nume_produs_update'";
// Executăm instrucțiunea SQL
if ($conn->query($sqlUpdateProdus) === TRUE) {
    echo "Produsul a fost șters cu succes.";
} else {
    echo "Eroare la ștergerea produsului: " . $conn->error;
}

// Închidem conexiunea la baza de date
$conn->close();
?>
