CREATE DATABASE IF NOT EXISTS test;
USE test;

ALTER TABLE utilizatori ADD UNIQUE (email);

CREATE TABLE IF NOT exists utilizatori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nume VARCHAR(50) NOT NULL,
    prenume VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    parola VARCHAR(255) NOT NULL,
    telefon VARCHAR(15) NOT NULL
);
CREATE TABLE if not exists tabela_produse (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nume VARCHAR(255),
    pret DECIMAL(10, 2),
    stoc INT
);
CREATE TABLE IF NOT EXISTS detalii_comanda (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nume_produs VARCHAR(255) NOT NULL,
  cantitate INT NOT NULL,
  pret DECIMAL(10, 2) NOT NULL,
  data_comanda TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO utilizatori (nume, prenume, email, parola, telefon)
VALUES ('Administrator', 'Admin', 'admin@example.com', 'parola_securizata', '123456789');

select * from utilizatori;
select * from detalii_comanda;
select * from tabela_produse;

INSERT INTO tabela_produse (nume, pret, stoc) VALUES
('Tudor Black Bay Bronze', 6000, 10),
('Tudor Pelagos', 5300, 10),
('Tudor Black Bay Chrono', 7700, 10),
('Tudor Fastrider Chrono', 4400, 10);

