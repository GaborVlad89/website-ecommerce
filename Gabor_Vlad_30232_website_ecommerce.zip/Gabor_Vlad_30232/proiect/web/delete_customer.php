<?php
global $conn;
include 'conect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])) {
    $customerId = $_POST["id"];

    // Verificăm dacă clientul există în baza de date
    $checkQuery = "SELECT * FROM utilizatori WHERE id = $customerId";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Executăm comanda de ștergere
        $deleteQuery = "DELETE FROM utilizatori WHERE id = $customerId";
        if ($conn->query($deleteQuery) === TRUE) {
            $response = array("message" => "Clientul a fost șters cu succes.");
        } else {
            $response = array("error" => "Eroare la ștergerea clientului: " . $conn->error);
        }
    } else {
        $response = array("error" => "Clientul nu există în baza de date.");
    }
} else {
    $response = array("error" => "Request invalid.");
}

echo json_encode($response);
$conn->close();
?>
