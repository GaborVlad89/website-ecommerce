<?php
global $conn;
$servername = "localhost:3306";
$username = "root";
$password = "root1";
$database = "test";

// Creează o conexiune
$conn = new mysqli($servername, $username, $password, $database);

// Verifică conexiunea
if ($conn->connect_error) {
    die("Conexiune eșuată: " . $conn->connect_error);
}

// Începe sesiunea
session_start();
?>
