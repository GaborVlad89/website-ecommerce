<?php
// Conexiunea la baza de date
global $conn;
include 'conect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productId = $_POST['id'];
    $action = $_POST['action'];
    $newPrice = $_POST['newPrice'];

    // Verificăm dacă acțiunea este validă (1 pentru adăugare, -1 pentru scădere, 0 pentru modificare preț)
    if ($action == 1 || $action == -1 || $action == 0) {
        // Obținem stocul și prețul actual ale produsului
        $sqlSelectProdus = "SELECT stoc, pret FROM tabela_produse WHERE id = '$productId'";
        $result = $conn->query($sqlSelectProdus);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $stocCurent = $row['stoc'];
            $pretCurent = $row['pret'];

            // Calculăm noul stoc
            $noulStoc = $stocCurent + $action;

            // Actualizăm stocul și, opțional, prețul în baza de date
            $sqlUpdateStoc = "UPDATE tabela_produse SET stoc = $noulStoc";
            if ($action == 0 && !empty($newPrice)) {
                $sqlUpdateStoc .= ", pret = $newPrice";
            }
            $sqlUpdateStoc .= " WHERE id = '$productId'";

            if ($conn->query($sqlUpdateStoc) === TRUE) {
                $response = array('message' => 'Stocul și prețul au fost actualizate cu succes.');
            } else {
                $response = array('error' => 'Eroare la actualizarea stocului și prețului: ' . $conn->error);
            }
        } else {
            $response = array('error' => 'Produsul nu a fost găsit.');
        }
    } else {
        $response = array('error' => 'Acțiune invalidă.');
    }

    // Returnăm răspunsul sub formă de JSON
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    echo "Acces interzis.";
}
// Închidem conexiunea la baza de date
$conn->close();
?>
