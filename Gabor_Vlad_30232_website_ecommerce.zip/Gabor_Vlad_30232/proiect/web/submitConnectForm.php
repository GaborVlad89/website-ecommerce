<?php
include 'conect.php';

function submitConnectForm($email, $password) {
    global $conn;
    $stmt = $conn->prepare("SELECT nume, parola FROM utilizatori WHERE email = ?");
    if (!$stmt) {
        die("Error in preparing statement: " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    if (!$stmt->execute()) {
        die("Eroare la interogarea bazei de date: " . $stmt->error);
    }
    $stmt->bind_result($userName, $hashedPassword);

    if ($stmt->fetch()) {
        if (password_verify($password, $hashedPassword)) {
            session_start();
            $_SESSION['userName'] = $userName;
            echo "Conectare reușită!";
        } else {
            echo "Date de conectare incorecte.";
        }
    } else {
        echo "Date de conectare incorecte.";
    }
    $stmt->close();
}
?>
